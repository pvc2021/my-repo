import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-dection',
  templateUrl: './change-dection.component.html',
  styleUrls: ['./change-dection.component.css']
})
export class ChangeDectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
