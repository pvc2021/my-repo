import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeDectionComponent } from './change-dection.component';

describe('ChangeDectionComponent', () => {
  let component: ChangeDectionComponent;
  let fixture: ComponentFixture<ChangeDectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeDectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeDectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
