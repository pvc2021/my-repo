import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {


  count=0;

  colors=["RED","GREEN","BLUE"];


  addColor(color:string){
console.log("New Color "+color);
    
   this.colors=[];
    this.colors.push(color);
    console.log("Updated colors :"+this.colors);
    
  }

  incrementCount(){
    this.count=this.count+1;
  }

  constructor() {
    console.log("===ParentComponent created====");
    
   }

  ngOnInit(): void {
    console.log("===ParentComponent ngOnInit====");
    }

 ngOnChanges(): void {
    console.log("===ParentComponent ngOnChanges===");
    }

    ngAfterViewChecked(): void {
      console.log("===ParentComponent ngAfterViewChecked===");
      }
    
      ngAfterContentChecked(): void {
        console.log("===ParentComponent ngAfterContentChecked===");
        }

  ngOnContentInit(): void {
    console.log("===ParentComponent ngOnContentInit===");
    }
  

    ngAfterContentInit(): void {
      console.log("===ParentComponent ngAfterContentInit===");
    }
    
    ngAfterViewInit(): void {
      console.log("===ParentComponent ngAfterViewInit===");
    }
    
    ngDoCheck(){
      console.log("===ParentComponent ngDoCheck===");
    }

}
