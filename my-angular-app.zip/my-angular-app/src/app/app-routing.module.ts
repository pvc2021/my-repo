import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChangeDectionComponent } from './change-dection/change-dection.component';
import { HomeComponent } from './home/home.component';
import { LocalizationComponent } from './localization/localization.component';

const routes: Routes = [

  {path:'localization',component:LocalizationComponent},
  {path:'home',component:HomeComponent},
  {path:'change',component:ChangeDectionComponent},
  {path:'**',component:HomeComponent}
  
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
