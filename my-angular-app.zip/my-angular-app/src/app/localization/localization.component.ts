import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-localization',
  templateUrl: './localization.component.html',
  styleUrls: ['./localization.component.css']
})
export class LocalizationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
