import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ChildComponent implements OnInit {


@Input()parentCount:any;

@Input()parentColors:any;

  constructor(private cdr:ChangeDetectorRef) {
    console.log("===ChildComponent created====");
   //this.cdr.detach();
   }



  ngOnInit(): void {
    console.log("===ChildComponent ngOnInit====");
    }

 ngOnChanges(): void {
    console.log("===ChildComponent ngOnChanges===");
    }

   
 ngOnDestroy(): void {
  console.log("===ChildComponent ngOnDestroy===");
  } 

  
  ngAfterViewChecked(): void {
  console.log("===ChildComponent ngAfterViewChecked===");
  }

  ngAfterContentChecked(): void {
    console.log("===ChildComponent ngAfterContentChecked===");
    }
  

    ngAfterContentInit(): void {
      console.log("===ChildComponent ngAfterContentInit===");
    }
    
    ngAfterViewInit(): void {
      console.log("===ChildComponent ngAfterViewInit===");
    }
    
    ngDoCheck(){
      console.log("===ChildComponent ngDoCheck===");
    }
 
}
